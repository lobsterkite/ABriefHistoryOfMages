export {default} from "./bd978e78ca52ddc6@96.js";
